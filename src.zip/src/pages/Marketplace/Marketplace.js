import Page from 'components/Page';
import React from 'react'
import './styles.scss'

function MarketPlace() {
  return (
    <Page>
      <div className="coming-soon">
        Coming Soon...
      </div>
    </Page>
  )
}

export default MarketPlace;