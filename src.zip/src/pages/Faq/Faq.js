import Page from 'components/Page';
import React from 'react'
import './styles.scss'

function Faq() {
  return (
    <Page>
      <div className="coming-soon">
        Coming Soon...
      </div>
    </Page>
  )
}

export default Faq;