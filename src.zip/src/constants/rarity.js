export const RARITY_TITLES = [
  'Gold',
  'Platinum',
  'Diamond',
  'Ruby'
]